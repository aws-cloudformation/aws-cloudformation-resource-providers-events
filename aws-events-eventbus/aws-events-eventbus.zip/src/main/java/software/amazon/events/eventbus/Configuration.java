package software.amazon.events.eventbus;

class Configuration extends BaseConfiguration {
    public Configuration() {
        super("aws-events-eventbus.json");
    }
}
